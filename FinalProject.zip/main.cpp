#include "Customer.hpp"
#include "Account.hpp"
#include "Transaction.hpp"
#include "ATM.hpp"

#include <iostream>

void printWelcomeScreen() {
    for (int i = 0; i < 10; i++) {
        std::cout << '*';
    }
    std::cout << std::endl;
}
int main() {
    ATM atm;
    atm.start();
    return 0;
}